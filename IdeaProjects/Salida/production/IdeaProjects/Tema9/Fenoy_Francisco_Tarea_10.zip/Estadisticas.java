package Tema9;

public interface Estadisticas {
    abstract public double precio();
}
